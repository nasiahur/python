import random
random.seed(253)

#kode dibawah ini mengasumsikan bahwa kartu yang akan dimiliki tiap pemain adalah 5 (sudah pasti)

mydeck=[]
for k in '23456789TJQKA':
    for g in 'SHDC':
        mydeck+=[k+g]

def deal(jumlahpemain, jumlahkartu=5, deck=mydeck):
    """Mengembalikan list of list
    """
    random.shuffle(mydeck)
    if len(mydeck)>=jumlahkartu*jumlahpemain:
    	return [mydeck[jumlahkartu*i:jumlahkartu*(i+1)] for i in range(jumlahpemain)]
    else:
        return 'Jumlah kartu di deck tidak mencukupi untuk {} pemain!'.format(jumlahpemain)
  
def poker(hands):
    """Mengembalikan  pemain terbaik dari list of hands

    poker([hand,...]) => hand
    """
    return max(hands, key=hand_rank)

def card_ranks(hand):
    """Mengembalikan list dengan kartu terurut menurun

    e.g. [3, 5, 4, 8, 2] => [8, 5, 4, 3, 2]
    """
    ranks = ['..23456789TJQKA'.index(r) for r, s in hand]
    ranks.sort()
    ranks.reverse()
    if (ranks == [14, 5, 4, 3, 2]):
        return [5, 4, 3, 2, 1]
    else:
        return ranks    
    
def straight(ranks):
    """Mengembalikan nilai True jika nilai kartu di tangan adalah straight

    e.g.
    [8, 7, 6, 5, 4] => True
    [8, 8, 5, 3, 2] => False
    """
    return len(set(ranks)) == 5 and (max(ranks)-min(ranks)) == 4
    
def flush(hand):
    """Mengembalikan nilai True jika kartu di tangan adalah flush

    e.g. ['3S', '7S', '5S', '9S', 'QS'] => True
    """
    rupa_kartu = [rk for v, rk in hand]
    return rupa_kartu[0]==rupa_kartu[1]==rupa_kartu[2]==rupa_kartu[3]==rupa_kartu[4]

def kind(n_times, ranks):
    """Mengembalikan nilai True jika kartu di tangan adalah n of kind

    e.g. kind(2, [8, 8, 5, 3, 2]) => True
    """
    for i in ranks:
        if ranks.count(i) == n_times: 
            return i
    return None

   
def two_pairs(ranks):
    """Mengembalikan nilai True jika kartu di tangan adalah two pairs

    e.g. [8, 8, 5, 5, 2] => True
    """
    pair = kind(2, ranks)
    lowpair = kind(2, list(reversed(ranks)))
    if pair and lowpair != pair:
        return (pair, lowpair)
    else:
        return None
    
def hand_rank(hand):
    """Mengembalikan nilai berupa tuple yang dapat dijadikan pembanding kartu di tangan.
    Lengkapi kode ini untuk semua jenis peringkat yang mungkin!
    """
    ranks = card_ranks(hand)
    if straight(ranks) and flush(hand):
        return (9, max(ranks))
    elif kind(4, ranks):
        return (8, kind(4, ranks))
    elif kind(3, ranks) and kind(2, ranks):
        return (7, kind(3, ranks), kind(2, ranks))
    elif flush(hand):
        return (6, ranks)
    elif straight(ranks):
        return (5, max(ranks))
    elif kind(3, ranks):
        return (4, kind(3, ranks), ranks)
    elif two_pairs(ranks):
        return (3, two_pairs(ranks), ranks)
    elif kind(2, ranks):
        return (2, kind(2, ranks), ranks)
    else:
        return (1, sum(ranks))

       