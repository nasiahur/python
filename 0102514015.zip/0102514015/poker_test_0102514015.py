import unittest
import poker_0102514015 as p 

class Test(unittest.TestCase):

    def setUp(self):
        self.sf1="TH JH QH KH AH".split()
        self.f2="QH 2H 6H 3H 2H".split()
        self.op3="9D 9H 8C KC AH".split()
        self.sf5 = "QC JC 9C 8C TC".split()
        self.fk6 = "3S 3C 3H 8D 3D".split()
        self.fh7 = "5S 8D 5C 5H 8S".split()
        self.f8 = "TS 2S 5S 5S 8S".split()
        self.s9 = "4D 5C 6H 3H 7H".split()
        self.k10 = "3C 3D 9D 3S 8H".split()
        self.tp11 = "6S 5S 5D 9H 9C".split()
        self.op12 = "TS TH 3S 5H 8D".split()
        self.hc13 = "AC 3H 5S 9S QD".split()

    def test_1_card_ranks(self):
        #pengujian 1
        self.assertEqual(p.card_ranks(self.sf1),[14,13,12,11,10])
        self.assertEqual(p.card_ranks(self.f2),[12,6,3,2,2])
        self.assertEqual(p.card_ranks(self.op3),[14,13,9,9,8])
        print '1. Pengujian fungsi card_rank() yang melibatkan salah satu kartu bergambar : \n"PASS"'  
        
    def test_2_card_ranks(self):
        #pengujian 2
        self.s4="2H 3H 4C 5C AH".split()
        self.assertEqual(p.card_ranks(self.s4),[5,4,3,2,1])
        print '\n2. Pengujian fungsi card_rank() untuk straight dengan as bernilai rendah : \n"PASS"'
    
    def test_3_hand_rank(self):
        #pengujian 3
        assert p.hand_rank(self.sf5) == (9, 12)
        assert p.hand_rank(self.fk6) == (8, 3)
        assert p.hand_rank(self.fh7) == (7, 5, 8)
        assert p.hand_rank(self.f8) == (6, [10, 8, 5, 5, 2])
        assert p.hand_rank(self.s9) == (5, 7)
        assert p.hand_rank(self.k10) == (4, 3, [9, 8, 3, 3, 3])
        assert p.hand_rank(self.tp11) == (3, (9, 5), [9, 9, 6, 5, 5])
        assert p.hand_rank(self.op12) == (2, 10, [10, 10, 8, 5, 3])
        assert p.hand_rank(self.hc13) == (1, 43)
 
        print '\n3. Pengujian untuk setiap fungsi yang ada dari fungsi hand_rank() : \n"PASS"'

    def test_4_poker(self):
        #pengujian 4
        self.jumlahpemain=5
        
        kartu_pemain=[]
        for c in range(3):
            self.kartu = p.deal(self.jumlahpemain)
            kartu_pemain += self.kartu

        assert p.poker([kartu_pemain[0], kartu_pemain[1], kartu_pemain[2], kartu_pemain[3], kartu_pemain[4]]) == kartu_pemain[1]
        assert p.poker([kartu_pemain[5], kartu_pemain[6], kartu_pemain[7], kartu_pemain[8], kartu_pemain[9]]) == kartu_pemain[9]
        assert p.poker([kartu_pemain[10], kartu_pemain[11], kartu_pemain[12], kartu_pemain[13], kartu_pemain[14]]) == kartu_pemain[11]  
        print '\n4. Tiga permainan dengan 5 pemain untuk menguji pemenang dari permainan : \n"PASS"' 

    def test_5_deal(self):
        #pengujian 5
        print '\n5.Dua kasus gagal dan berhasil apakah deck mencukupi untuk sejumlah pemain : \n'
        print ' >>Deal 4 pemain : {}'.format(p.deal(4))
        print '>>Deal 24 pemain : {}'.format(p.deal(24))
   
       
if __name__ == '__main__':
        unittest.main()
